package com.example.profilecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfilecrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfilecrudApplication.class, args);
	}

}
